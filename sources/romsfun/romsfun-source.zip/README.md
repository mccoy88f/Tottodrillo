# ROMsFun Source

Sorgente per integrare ROMsFun.com come sorgente di ROM in Tottodrillo.

## Informazioni

- **Sito**: https://romsfun.com/
- **Versione**: 1.0.0
- **Tipo**: Python Source

## Piattaforme Supportate

Le piattaforme vengono mappate tramite `platform_mapping.json`. Per aggiungere nuove piattaforme o aggiornare il mapping, modifica il file `platform_mapping.json`.

## Installazione

Questa sorgente viene installata automaticamente quando viene aggiunta all'app Tottodrillo.

## Disclaimer

Questa sorgente funziona come wrapper per ROMsFun.com. Tutti i meriti vanno al sito ROMsFun.com, grande ed importante progetto per tutta la comunità.

Le sorgenti funzionano così senza garanzie e si ricorda di utilizzarle nel rispetto delle leggi vigenti nel proprio stato.

